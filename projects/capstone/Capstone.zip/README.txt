# Machine Learning Engineer Nanodegree
## Specializations
## Project: Capstone Project

**Note**

The libraries for this project are: sklearn, matplotlib, pandas, collections, imblearn. I used Jupyter Notebook and the Ipython version 
is 6.4.0. The version of python is 3.6.5
